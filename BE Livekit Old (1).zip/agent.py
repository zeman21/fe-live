import os
import logging
from typing import Literal, Optional
from pydantic import BaseModel, Field
from dotenv import load_dotenv
from livekit.agents import (
    AutoSubscribe,
    JobContext,
    JobProcess,
    WorkerOptions,
    cli,
    llm,
)
from livekit.agents.pipeline import VoicePipelineAgent
from livekit.plugins import openai, deepgram, silero, azure, elevenlabs, google

from llama_index.core import (
    SimpleDirectoryReader,
    StorageContext,
    VectorStoreIndex,
    load_index_from_storage,
)
from llama_index.core.schema import MetadataMode


load_dotenv(dotenv_path=".env.local")
logger = logging.getLogger("voice-agent")


def prewarm(proc: JobProcess):
    proc.userdata["vad"] = silero.VAD.load()


class FunctionDescription(BaseModel):
    name: str
    description: str
    parameters: dict

class GetProductInfoArgs(BaseModel):
    product_name: str = Field(..., description="The name of the product")

def get_product_info(args: GetProductInfoArgs):
    """Retrieves information about a product from a database or API."""
    product_name = args.product_name
    # ... (Your logic to fetch product info based on product_name)
    # Example:
    product_data = {
        "Emas Batangan Antam": {
            "description": "Investasi emas murni bersertifikat LBMA",
            "harga": "Rp 1.050.000/gram",
        },
        "Gadai Emas": {
            "description": "Pinjaman dengan jaminan emas",
            "suku bunga": "Mulai dari 0.75% per bulan",
        },
    }
    if product_name in product_data:
        return product_data[product_name]
    else:
        return f"Maaf, aku tidak menemukan informasi tentang produk '{product_name}'"

functions = [
    FunctionDescription(
        name="get_product_info",
        description="Get information about a specific Pegadaian product.",
        parameters=GetProductInfoArgs.model_json_schema(),
    ),
]





# check if storage already exists
PERSIST_DIR = "./retrieval-engine-storage"
if not os.path.exists(PERSIST_DIR):
    # load the documents and create the index
    documents = SimpleDirectoryReader("data").load_data()
    index = VectorStoreIndex.from_documents(documents)
    # store it for later
    index.storage_context.persist(persist_dir=PERSIST_DIR)
else:
    # load the existing index
    storage_context = StorageContext.from_defaults(persist_dir=PERSIST_DIR)
    index = load_index_from_storage(storage_context)


async def entrypoint(ctx: JobContext):
    system_msg = llm.ChatMessage(
        role="system",
        content=(
            "You are a Customer Service created by Telkom satu kosong delapan. Your interface with users will be voice. "
            "You are a humanis person, empaty, proactive, preety"
            "You call yourself 'Aku' and the person you are talking to can be called 'Kamu'"
            "You should use short and concise responses, and avoiding usage of unpronouncable punctuation."
        ),
    )
    initial_ctx = llm.ChatContext()
    initial_ctx.messages.append(system_msg)

    async def _will_synthesize_assistant_reply(
        assistant: VoicePipelineAgent, chat_ctx: llm.ChatContext
    ):
        ctx_msg = system_msg.copy()
        user_msg = chat_ctx.messages[-1]
        retriever = index.as_retriever()
        nodes = await retriever.aretrieve(user_msg.content)

        ctx_msg.content = "You are customer service Telkom satu kosong delapan, you interactive human, humanize & smart. Context that might help answer the user's question only use this context as source of truth:"
        for node in nodes:
            node_content = node.get_content(metadata_mode=MetadataMode.LLM)
            ctx_msg.content += f"\n\n{node_content}"

        chat_ctx.messages[0] = ctx_msg  # the first message is the system message
        return assistant.llm.chat(chat_ctx=chat_ctx)

    logger.info(f"connecting to room {ctx.room.name}")
    await ctx.connect(auto_subscribe=AutoSubscribe.AUDIO_ONLY)

    # Wait for the first participant to connect
    participant = await ctx.wait_for_participant()
    logger.info(f"starting voice assistant for participant {participant.identity}")

    # This project is configured to use Deepgram STT, OpenAI LLM and TTS plugins
    # Other great providers exist like Cartesia and ElevenLabs
    # Learn more and pick the best one for your app:
    # https://docs.livekit.io/agents/plugins
    assistant = VoicePipelineAgent(
        vad=ctx.proc.userdata["vad"],
        stt=deepgram.STT(),
        # stt=azure.STT(languages=["id-ID"]),
        # llm=openai.LLM(model="gpt-4o-mini"),
        # llm=openai.LLM(model="gpt-3.5-turbo"),
        llm=openai.LLM(
            base_url="https://api.cerebras.ai/v1",
            api_key=os.environ.get("CEREBRAS_API_KEY"),
            model="llama3.1-8b",
        ),
        # tts=azure.TTS(voice="id-ID-GadisNeural", language="id-ID"),
        # tts=google.TTS(),
        tts=elevenlabs.TTS(),
        # tts=openai.TTS(),
        interrupt_speech_duration=0.5,
        interrupt_min_words=0,
        chat_ctx=initial_ctx,
        before_llm_cb=_will_synthesize_assistant_reply,
    )

    assistant.start(ctx.room, participant)

    # The agent should be polite and greet the user when it joins :)
    await assistant.say(
        "Halo Telkom satu kosong delapan disini, ada yang bisa Riri bantu?", allow_interruptions=True
    )


if __name__ == "__main__":
    cli.run_app(
        WorkerOptions(
            entrypoint_fnc=entrypoint,
            prewarm_fnc=prewarm,
        ),
    )
