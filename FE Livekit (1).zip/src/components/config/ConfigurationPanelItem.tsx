import { ReactNode } from "react";
import { PlaygroundDeviceSelector } from "@/components/playground/PlaygroundDeviceSelector";
import { TrackToggle } from "@livekit/components-react";
import { Track } from "livekit-client";

type ConfigurationPanelItemProps = {
  title: string;
  children?: ReactNode;
  deviceSelectorKind?: MediaDeviceKind;
};

export const ConfigurationPanelItem: React.FC<ConfigurationPanelItemProps> = ({
  children,
  title,
  deviceSelectorKind,
}) => {
  return (
    <div className="w-full flex  text-black py-4 space-x-2">
       {deviceSelectorKind && (
            <TrackToggle
              className="px-2 py-1 bg-white-900 text-black-300 border-black rounded-sm  text-black"
              source={
                deviceSelectorKind === "audioinput"
                  ? Track.Source.Microphone
                  : Track.Source.Camera
              }
            />
        )}
      <div className="px-4 py-2 text-xs text-black leading-normal">
        {children}
      </div>
    </div>
  );
};
