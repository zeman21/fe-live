export const CloudConnect = ({ accentColor }: { accentColor: string }) => {
  return null;
};

export const CLOUD_ENABLED = false;
